@echo off
chcp 65001 > nul
setlocal EnableDelayedExpansion
cd /d "%~dp0"

set "APP_VERSION=2.0.0"

:menu
cls
echo.
echo    ______                       __
echo   /_  __/____ _____  _______ / /_
echo    / /  / __ `/ __ \/ ___/ _ \/ __/
echo   / /  / /_/ / /_/ / /  /  __/ /_
echo  /_/   \__,_/ .___/_/   \___/\__/
echo            /_/
echo.
echo   ZAPRET MENU  v%APP_VERSION%
echo   Обход блокировок Discord / YouTube
echo   ------------------------------------------------------
echo.
echo    1. Подобрать рабочую стратегию (тест по очереди)
echo    2. Управление службой (установка / статус / автозапуск)
echo    3. Остановить все запущенные стратегии
echo    4. Показать README
echo    0. Выход
echo.
set "menu_choice="
set /p "menu_choice=  Выбери пункт (0-4): "

if "%menu_choice%"=="1" goto strategy_test
if "%menu_choice%"=="2" goto service_manager
if "%menu_choice%"=="3" goto stop_all
if "%menu_choice%"=="4" goto open_readme
if "%menu_choice%"=="0" exit /b
goto menu


:: ============================================================
:: ПОДБОР СТРАТЕГИИ
:: ============================================================
:strategy_test
cls
call :kill_winws

echo.
echo   ВЫБОР СТРАТЕГИИ ОБХОДА
echo   ------------------------------------------------------
echo   Разные провайдеры блокируют по-разному, поэтому нет
echo   одной стратегии, которая работает у всех. Запускай их
echo   по очереди и проверяй, открылись ли заблокированные
echo   сайты. Как найдёшь рабочую — поставь её в автозапуск
echo   через пункт "2. Управление службой".
echo.

set "count=0"
for /f "delims=" %%F in ('powershell -NoProfile -Command "Get-ChildItem -LiteralPath '.' -Filter 'general*.bat' | Sort-Object { [Regex]::Replace($_.Name, '(\d+)', { $args[0].Value.PadLeft(8, '0') }) } | ForEach-Object { $_.Name }"') do (
    set /a count+=1
    set "file!count!=%%F"
    call :describe_strategy "%%F"
    echo    !count!. %%F  --  !STRAT_DESC!
)

echo.
echo    0. Назад
echo.
set "s_choice="
set /p "s_choice=  Номер стратегии для запуска: "
if "%s_choice%"=="0" goto menu

set "selected=!file%s_choice%!"
if not defined selected (
    echo.
    echo   Неверный выбор.
    pause
    goto strategy_test
)

echo.
echo   Запускаю: !selected!
call "!selected!"
echo.
echo   Стратегия запущена в фоне ^(процесс winws.exe в диспетчере задач^).
echo   Проверь в браузере заблокированные ранее сайты.
echo.
echo   - Если сайты ОТКРЫЛИСЬ — зайди в п.2 "Управление службой"
echo     и установи эту стратегию в автозапуск, чтобы обход
echo     работал постоянно и после перезагрузки.
echo   - Если НЕ открылись — вернись в это меню, останови
echo     ^(п.3^) и попробуй следующую стратегию из списка.
echo.
pause
goto menu


:: Подбирает короткое описание по имени файла стратегии
:describe_strategy
set "n=%~1"
set "STRAT_DESC=базовая универсальная стратегия"

echo !n! | findstr /I /C:"FAKE TLS AUTO" >nul
if not errorlevel 1 (
    set "STRAT_DESC=fake-пакеты с автоподбором TTL под TLS"
    goto describe_done
)

echo !n! | findstr /I /C:"SIMPLE FAKE" >nul
if not errorlevel 1 (
    set "STRAT_DESC=упрощённый fake-метод, ниже нагрузка на канал"
    goto describe_done
)

echo !n! | findstr /I "ALT" >nul
if not errorlevel 1 (
    set "STRAT_DESC=альтернативный набор split/disorder параметров"
    goto describe_done
)

:describe_done
exit /b


:: ============================================================
:: ОСТАНОВКА ВСЕХ СТРАТЕГИЙ
:: ============================================================
:kill_winws
tasklist /FI "IMAGENAME eq winws.exe" | find /I "winws.exe" > nul
if not errorlevel 1 (
    taskkill /IM winws.exe /F > nul 2>&1
)
exit /b

:stop_all
cls
call :kill_winws
echo.
echo   Все запущенные вручную стратегии остановлены.
echo   ^(Если стратегия установлена как служба — используй
echo   пункт "2. Управление службой" -^> "Remove Services"^)
echo.
pause
goto menu


:: ============================================================
:: СЛУЖБА / ПОЛНОЕ МЕНЮ
:: ============================================================
:service_manager
call service.bat
goto menu


:: ============================================================
:: README
:: ============================================================
:open_readme
start "" notepad "README.md"
goto menu
