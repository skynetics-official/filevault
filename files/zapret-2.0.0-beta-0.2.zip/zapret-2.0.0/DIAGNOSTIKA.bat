@echo off
chcp 866 > nul

cd /d "%~dp0"
set "BIN=%~dp0bin\"
set "LISTS=%~dp0lists\"

echo.
echo   DIAGNOSTIKA ZAPRET
echo   ------------------------------------------------------
echo   Seychas zapustim winws.exe NE svernuto, chtoby uvidet
echo   realnuyu oshibku, esli process zakryvaetsya sam.
echo.
echo   Proverka 1: prava administratora
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo   [OSHIBKA] Skript zapushchen BEZ prav administratora!
    echo   Zakroy eto okno, klikni pravoy knopkoy po ZAPRET-MENU.bat
    echo   i vyberi "Zapustit ot imeni administratora".
    echo.
    pause
    exit /b
) else (
    echo   [OK] Prava administratora est.
)

echo.
echo   Proverka 2: fayly dvizhka na meste
if not exist "%BIN%winws.exe" (
    echo   [OSHIBKA] Ne nayden winws.exe - antivirus mog udalit
    echo   ego v karantin. Provert Zashchitu Windows -^> Istoriya
    echo   zashchity, vosstanovi fayl i dobav papku v isklyucheniya.
    pause
    exit /b
)
if not exist "%BIN%WinDivert64.sys" (
    echo   [OSHIBKA] Ne nayden WinDivert64.sys - antivirus mog
    echo   udalit ego v karantin. Sm. vyshe.
    pause
    exit /b
)
echo   [OK] Fayly dvizhka na meste.

echo.
echo   Zapuskayu winws.exe v obychnom okne ^(ne svernuto^)...
echo   Esli okno seychas zakroetsya samo - text oshibki
echo   uspeet melknut, no eto okno diagnostiki ostanetsya
echo   otkrytym, chtoby ty uspel prochitat.
echo.
echo   ------------------------------------------------------

"%BIN%winws.exe" --wf-tcp=80,443 --wf-udp=443 --filter-tcp=80,443 --hostlist-domains=youtube.com --dpi-desync=fake --dpi-desync-repeats=6

echo   ------------------------------------------------------
echo.
echo   Process zavershen. Esli vyshe est tekst so slovom
echo   "error" ili "failed" - skopiruy ego i prishli polnostyu.
echo.
pause
